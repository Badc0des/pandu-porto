const s=globalThis.__sveltekit_x871vi?.base??"/portfolio",t=globalThis.__sveltekit_x871vi?.assets??s;export{t as a,s as b};

import * as universal from '../entries/pages/__language_lang__/_layout.ts.js';

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/__language_lang__/_layout.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/[[language=lang]]/+layout.ts";
export const imports = ["_app/immutable/nodes/3.YIIPln5X.js","_app/immutable/chunks/runtime.nm5hb8rq.js","_app/immutable/chunks/index.rK6CHotB.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/index.--F_gRC0.js","_app/immutable/chunks/app._QD7NOY9.js","_app/immutable/chunks/paths.wPZ2Tgq1.js","_app/immutable/chunks/each.-oqiv04n.js","_app/immutable/chunks/entry.6OwFKuot.js","_app/immutable/chunks/stores.5k7IVaS-.js"];
export const stylesheets = ["_app/immutable/assets/3.qfa6T5Rq.css","_app/immutable/assets/app.TxeR7T8A.css"];
export const fonts = [];

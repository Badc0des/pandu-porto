import * as server from '../entries/pages/__language_lang__/_page.server.ts.js';

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/__language_lang__/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/[[language=lang]]/+page.server.ts";
export const imports = ["_app/immutable/nodes/6.5sI95hNk.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/index.--F_gRC0.js","_app/immutable/chunks/paths.wPZ2Tgq1.js","_app/immutable/chunks/each.-oqiv04n.js","_app/immutable/chunks/runtime.nm5hb8rq.js","_app/immutable/chunks/index.rK6CHotB.js"];
export const stylesheets = ["_app/immutable/assets/6.0hXEuMdE.css"];
export const fonts = [];

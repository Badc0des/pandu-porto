import * as universal from '../entries/pages/blog/_post_blog_/_page.ts.js';
import * as server from '../entries/pages/blog/_post_blog_/_page.server.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/blog/_post_blog_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/blog/[post=blog]/+page.ts";
export { server };
export const server_id = "src/routes/blog/[post=blog]/+page.server.ts";
export const imports = ["_app/immutable/nodes/5.h9WjEXXy.js","_app/immutable/chunks/preload-helper.0HuHagjb.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/index.--F_gRC0.js"];
export const stylesheets = [];
export const fonts = [];

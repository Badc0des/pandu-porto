

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/__language_lang__/projects/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/8.l9BAKVW1.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/index.--F_gRC0.js","_app/immutable/chunks/each.-oqiv04n.js","_app/immutable/chunks/paths.wPZ2Tgq1.js","_app/immutable/chunks/index.rK6CHotB.js","_app/immutable/chunks/runtime.nm5hb8rq.js"];
export const stylesheets = ["_app/immutable/assets/8.yIXJrGPr.css"];
export const fonts = [];

import * as universal from '../entries/pages/_layout.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.N3rQWF0u.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/stores.5k7IVaS-.js","_app/immutable/chunks/entry.6OwFKuot.js","_app/immutable/chunks/index.rK6CHotB.js","_app/immutable/chunks/paths.wPZ2Tgq1.js","_app/immutable/chunks/app._QD7NOY9.js","_app/immutable/chunks/runtime.nm5hb8rq.js","_app/immutable/chunks/index.--F_gRC0.js"];
export const stylesheets = ["_app/immutable/assets/app.TxeR7T8A.css"];
export const fonts = [];

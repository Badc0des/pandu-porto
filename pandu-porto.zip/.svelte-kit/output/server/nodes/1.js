

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.IT4eyeWD.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/index.--F_gRC0.js","_app/immutable/chunks/stores.5k7IVaS-.js","_app/immutable/chunks/entry.6OwFKuot.js","_app/immutable/chunks/index.rK6CHotB.js","_app/immutable/chunks/paths.wPZ2Tgq1.js"];
export const stylesheets = [];
export const fonts = [];

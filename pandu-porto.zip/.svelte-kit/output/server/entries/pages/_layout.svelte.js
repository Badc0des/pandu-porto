import { c as create_ssr_component } from "../../chunks/ssr.js";
/* empty css               */
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  let previous = data.pathname;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  {
    {
      let pathname = data.pathname;
      if (pathname.startsWith("/blog") !== previous.startsWith("/blog"))
        ;
      previous = pathname;
    }
  }
  return `<div>${slots.default ? slots.default({}) : ``}</div>`;
});
export {
  Layout as default
};

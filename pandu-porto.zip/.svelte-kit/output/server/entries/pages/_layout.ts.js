import { inject } from "@vercel/analytics";
import "../../chunks/client.js";
import "../../chunks/i18n.js";
const prerender = true;
const load = ({ url, params }) => {
  const { pathname } = url;
  console.log(pathname, params);
  return { pathname };
};
inject({ mode: "production" });
export {
  load,
  prerender
};

import { s as subscribe, g as get_store_value } from "../../../chunks/utils.js";
import { c as create_ssr_component, e as escape, a as add_styles, v as validate_component, b as add_attribute, d as each } from "../../../chunks/ssr.js";
/* empty css                  */
import { b as base } from "../../../chunks/paths.js";
import { a as $format, b as $locales, $ as $locale } from "../../../chunks/runtime.js";
import { b as baseLocale } from "../../../chunks/i18n.js";
import "../../../chunks/client.js";
import { p as page } from "../../../chunks/stores.js";
const css$3 = {
  code: ".icon.svelte-xaud44{mask-size:100%;mask-repeat:no-repeat;-webkit-mask-size:100%;-webkit-mask-repeat:no-repeat;image-rendering:pixelated;width:1.5em;height:1.5em}",
  map: null
};
const ImgIcon = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { src } = $$props;
  let { class: className = "" } = $$props;
  if ($$props.src === void 0 && $$bindings.src && src !== void 0)
    $$bindings.src(src);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  $$result.css.add(css$3);
  return `<div class="${"icon " + escape(className, true) + " svelte-xaud44"}"${add_styles({
    "mask-image": `url('${src}')`,
    "-webkit-mask-image": `url('${src}')`
  })}></div>`;
});
const css$2 = {
  code: "nav.navBar.svelte-1q9kxe5.svelte-1q9kxe5.svelte-1q9kxe5{background-color:var(--bg1);display:flex;flex-direction:row;justify-content:space-between}nav.navBar.svelte-1q9kxe5>ul.svelte-1q9kxe5.svelte-1q9kxe5{display:flex;flex-direction:row;list-style:none;margin:0;padding:0}#navLinks.svelte-1q9kxe5>.navElement span.svelte-1q9kxe5.svelte-1q9kxe5{display:none}@media(min-width: 974px){#navLinks.svelte-1q9kxe5>.navElement span.svelte-1q9kxe5.svelte-1q9kxe5{display:block}}#socialLinks.svelte-1q9kxe5.svelte-1q9kxe5.svelte-1q9kxe5{gap:0em}#socialLinks.svelte-1q9kxe5>.navElement.svelte-1q9kxe5.svelte-1q9kxe5:not(.alwaysVisible){display:none}@media(min-width: 510px){#socialLinks.svelte-1q9kxe5>.navElement.svelte-1q9kxe5.svelte-1q9kxe5:not(.alwaysVisible){display:block}}#socialLinks.svelte-1q9kxe5>.navElement.svelte-1q9kxe5:not(.alwaysVisible) div.icon{width:1.5em;height:1.5em;image-rendering:pixelated}@media(min-width: 640px){#socialLinks.svelte-1q9kxe5>.navElement.svelte-1q9kxe5:not(.alwaysVisible) div.icon{width:2em;height:2em}}#socialLinks.svelte-1q9kxe5>.navElement.svelte-1q9kxe5:not(.alwaysVisible)>a.svelte-1q9kxe5{padding:0em 0.8em;height:100%}.navElement.svelte-1q9kxe5>a.svelte-1q9kxe5.svelte-1q9kxe5,.navElement.svelte-1q9kxe5 .darkToggle.svelte-1q9kxe5.svelte-1q9kxe5{display:flex;align-items:center;gap:0.5em;padding:1em 1.25em;background-color:transparent;cursor:pointer}.navElement.svelte-1q9kxe5>a.svelte-1q9kxe5.svelte-1q9kxe5:hover,.navElement.svelte-1q9kxe5 .darkToggle.svelte-1q9kxe5.svelte-1q9kxe5:hover,.navElement.svelte-1q9kxe5>a.svelte-1q9kxe5.svelte-1q9kxe5:focus,.navElement.svelte-1q9kxe5 .darkToggle.svelte-1q9kxe5.svelte-1q9kxe5:focus{background-color:var(--bg2)}.navElement.svelte-1q9kxe5>a.svelte-1q9kxe5.svelte-1q9kxe5:visited,.navElement.svelte-1q9kxe5 .darkToggle.svelte-1q9kxe5.svelte-1q9kxe5:visited{color:inherit}.darkToggle.svelte-1q9kxe5.svelte-1q9kxe5.svelte-1q9kxe5{padding:0em 0.8em !important;height:100%}.blueLink.svelte-1q9kxe5.svelte-1q9kxe5.svelte-1q9kxe5{color:var(--fgBlue)}.purpleLink.svelte-1q9kxe5.svelte-1q9kxe5.svelte-1q9kxe5{color:var(--fgPurple)}.aquaLink.svelte-1q9kxe5.svelte-1q9kxe5.svelte-1q9kxe5{color:var(--fgAqua)}",
  map: null
};
const NavBar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $baseLocale, $$unsubscribe_baseLocale;
  let $_, $$unsubscribe__;
  $$unsubscribe_baseLocale = subscribe(baseLocale, (value) => $baseLocale = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$result.css.add(css$2);
  $$unsubscribe_baseLocale();
  $$unsubscribe__();
  return `<nav class="navBar pixelSimpleBorder svelte-1q9kxe5"><ul id="navLinks" class="svelte-1q9kxe5"><li class="navElement blueLink svelte-1q9kxe5"><a href="${escape($baseLocale, true) + "/"}" class="svelte-1q9kxe5">${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/Home.png",
      class: "bgFgBlue"
    },
    {},
    {}
  )} <span class="svelte-1q9kxe5">${escape($_("navigation.home"))}</span></a></li> <li class="navElement purpleLink svelte-1q9kxe5"><a href="${escape($baseLocale, true) + "/projects"}" class="svelte-1q9kxe5">${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/Folder.png",
      class: "bgFgPurple"
    },
    {},
    {}
  )} <span class="svelte-1q9kxe5">${escape($_("navigation.projects"))}</span></a></li> <li class="navElement aquaLink svelte-1q9kxe5"><a href="${escape($baseLocale, true) + "/contact"}" class="svelte-1q9kxe5">${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/Contact.png",
      class: "bgFgAqua"
    },
    {},
    {}
  )} <span class="svelte-1q9kxe5">${escape($_("navigation.contact"))}</span></a></li></ul> <ul id="socialLinks" class="svelte-1q9kxe5"><li class="navElement alwaysVisible hideNotJavascript svelte-1q9kxe5"><button class="darkToggle svelte-1q9kxe5"${add_attribute("title", $_("navigation.toggle_dark_mode"), 0)}>${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: `${base}/icons/Sun.png`,
      class: "bgFgBlue"
    },
    {},
    {}
  )}</button></li> <li class="navElement svelte-1q9kxe5"><a href="http://discordapp.com/users/530819150969438208" target="_blank"${add_attribute("title", $_("navigation.discord_user"), 0)} class="svelte-1q9kxe5">${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/Discord.png",
      class: "bgDiscord"
    },
    {},
    {}
  )}</a></li> <li class="navElement svelte-1q9kxe5"><a href="https://github.com/JezerM" target="_blank"${add_attribute("title", $_("navigation.github_profile"), 0)} class="svelte-1q9kxe5">${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/GitHub.png",
      class: "bgWhite"
    },
    {},
    {}
  )}</a></li> <li class="navElement svelte-1q9kxe5"><a href="https://www.linkedin.com/in/jezer-josué-mejía-otero-111b39227/" target="_blank"${add_attribute("title", $_("navigation.linkedin_profile"), 0)} class="svelte-1q9kxe5">${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/LinkedIn.png",
      class: "bgLinkedIn"
    },
    {},
    {}
  )}</a></li></ul> </nav>`;
});
function getUnlocalizedPath(path) {
  let route = path;
  if (route?.startsWith("/"))
    route = route.substring(1);
  const splitted = route?.split("/");
  if (splitted && get_store_value($locales).includes(splitted[0])) {
    splitted?.shift();
    route = splitted?.join("/") ?? null;
  }
  if (splitted && base == splitted[0]) {
    splitted?.shift();
    route = splitted?.join("/") ?? null;
  }
  return route;
}
function localizePath(lang) {
  let route = get_store_value(page).route.id ?? "";
  route = route?.replace("[[language=lang]]", "");
  let endRoute = `${base}/${lang}/${route}`;
  if (lang == "en")
    endRoute = `${base}/${route}`;
  return endRoute.replace(/\/+/g, "/");
}
const css$1 = {
  code: '.infoContainer.svelte-ochjyr.svelte-ochjyr{padding:1.5em;background-color:var(--bg1);display:flex;flex-direction:column;gap:0.5em}@media(min-width: 640px){.infoContainer.svelte-ochjyr.svelte-ochjyr{padding:2em}}.data.svelte-ochjyr.svelte-ochjyr{display:flex;width:100%;flex-direction:row;justify-content:space-between;align-items:center;gap:0.5em}.data.svelte-ochjyr>span.svelte-ochjyr:last-child{text-align:end}.blue.svelte-ochjyr.svelte-ochjyr{color:var(--fgBlue)}.actionContainer.svelte-ochjyr.svelte-ochjyr{display:flex;position:relative}.actionContainer.svelte-ochjyr.svelte-ochjyr::before{content:"";width:100%;height:100%;display:block;position:absolute;background-color:var(--fg);z-index:-1}.actionContainer.svelte-ochjyr>.actionElement.svelte-ochjyr{appearance:none;box-sizing:border-box;background-color:var(--bg1);border-radius:0;border:0;margin:0.3rem;padding:0.5em 1em;color:var(--fg);font-family:Monocraft;font-size:14px;transition:background-color 0.25s}.actionContainer.svelte-ochjyr>.actionElement.svelte-ochjyr:hover{background-color:var(--bg2)}.selectIcon{position:absolute;top:50%;bottom:50%;margin-top:auto;margin-bottom:auto;right:0.75em;pointer-events:none}#localeOptionsContainer.svelte-ochjyr.svelte-ochjyr{width:100%}#localeOptions.svelte-ochjyr.svelte-ochjyr{width:-webkit-fill-available;width:fill-available;width:-moz-available;position:relative}#cvLink.svelte-ochjyr.svelte-ochjyr{display:flex;gap:0.5em;padding:0.5em;transition:background-color 0.25s}#cvLink.svelte-ochjyr.svelte-ochjyr:hover{background-color:var(--bg2)}.localeLinkContainer.svelte-ochjyr.svelte-ochjyr{display:none;flex-direction:column;padding-top:0.25em}.localeLinkContainer.svelte-ochjyr ul.svelte-ochjyr{margin:0;margin-top:0.5em}.localeLinkContainer.svelte-ochjyr ul li.svelte-ochjyr{transition:color 0.25s}.localeLinkContainer.svelte-ochjyr ul li.svelte-ochjyr:hover{color:var(--fgBlue)}',
  map: null
};
function getYearDifference(time1, time2) {
  const diffTime = time1 - time2;
  const ageDate = new Date(diffTime);
  return Math.abs(ageDate.getUTCFullYear() - 1970);
}
const ExtraData = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let data;
  let $_, $$unsubscribe__;
  let $locale$1, $$unsubscribe_locale;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_locale = subscribe($locale, (value) => $locale$1 = value);
  let cvLang;
  const bornDate = new Date(2003, 11, 5);
  const now = Date.now();
  $$result.css.add(css$1);
  {
    switch ($locale$1) {
      case "es":
        cvLang = "spanish";
        break;
      case "en":
      default:
        cvLang = "english";
        break;
    }
  }
  data = {
    age: getYearDifference(now, bornDate.getTime()),
    birthday: $_("extra_data.birthday_value"),
    country: "Nicaragua",
    gender: $_("extra_data.gender_value")
  };
  $$unsubscribe__();
  $$unsubscribe_locale();
  return `<div class="infoContainer pixelBorder svelte-ochjyr"><h3>${escape($_("extra_data.title"))}</h3> ${each(Object.entries(data), ([key, value]) => {
    return `<div class="data svelte-ochjyr"><span class="svelte-ochjyr">${escape($_(`extra_data.${key}`))}</span> <span class="svelte-ochjyr">${escape(value)}</span> </div>`;
  })} <div class="data svelte-ochjyr"><label for="cvLink" data-svelte-h="svelte-1mrpbo5">Currículum Vitae</label> <div class="actionContainer pixelSimpleBorder svelte-ochjyr"><a id="cvLink" class="actionElement pixelSimpleBorder svelte-ochjyr" href="${escape(base, true) + "/cv/" + escape(cvLang, true) + ".pdf"}" target="_blank"${add_attribute("title", $_("extra_data.cv_title"), 0)}><span>${escape($_("extra_data.cv_open"))}</span> ${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/Folder.png",
      class: "bgFg"
    },
    {},
    {}
  )}</a></div></div> <span class="blue svelte-ochjyr" data-svelte-h="svelte-cp0w9i">#SOSNicaragua</span> <div id="localeOptionsContainer" class="actionContainer pixelSimpleBorder hideNotJavascript svelte-ochjyr"><select id="localeOptions" class="actionElement pixelSimpleBorder svelte-ochjyr"><option value="en" ${$locale$1 == "en" ? "selected" : ""}>English</option><option value="es" ${$locale$1 == "es" ? "selected" : ""}>Español</option></select> ${validate_component(ImgIcon, "ImgIcon").$$render(
    $$result,
    {
      src: base + "/icons/CaretDown.png",
      class: "bgFg selectIcon"
    },
    {},
    {}
  )}</div> <div class="localeLinkContainer flexNotJavascript svelte-ochjyr"><span>${escape($_("extra_data.language"))}</span> <ul class="svelte-ochjyr" data-svelte-h="svelte-1ye7vrh"><li class="svelte-ochjyr"><a${add_attribute("href", localizePath("en"), 0)}>English</a></li> <li class="svelte-ochjyr"><a${add_attribute("href", localizePath("es"), 0)}>Spanish</a></li></ul></div> </div>`;
});
const css = {
  code: ".transitionContainer.svelte-hy9bpi{height:fit-content;display:grid;grid-template-rows:1fr;grid-template-columns:1fr}.transitionContainer.svelte-hy9bpi>*{grid-column:1;grid-row:1}main.svelte-hy9bpi{grid-column:span 1 / span 1;padding:1.5em;background-color:var(--bg1)}@media(min-width: 640px){main.svelte-hy9bpi{padding:2em}}@media(min-width: 1024px){main.svelte-hy9bpi{grid-column:span 2 / span 2}}@media(min-width: 1280px){main.svelte-hy9bpi{grid-column:span 3 / span 3}}aside.svelte-hy9bpi{width:100%;grid-column:span 1 / span 1}.mainContainer.svelte-hy9bpi{display:grid;grid-template-columns:repeat(1, minmax(0, 1fr));margin-top:2em;gap:2em}@media(min-width: 1024px){.mainContainer.svelte-hy9bpi{grid-template-columns:repeat(3, minmax(0, 1fr))}}@media(min-width: 1280px){.mainContainer.svelte-hy9bpi{grid-template-columns:repeat(4, minmax(0, 1fr))}}",
  map: null
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  let previous = data.pathname;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$result.css.add(css);
  {
    {
      getUnlocalizedPath(previous);
      getUnlocalizedPath(data.pathname);
      previous = data.pathname;
    }
  }
  $$unsubscribe__();
  return `${$$result.head += `<!-- HEAD_svelte-sus4vx_START --><meta name="description"${add_attribute("content", $_("head.description"), 0)}><meta property="og:description"${add_attribute("content", $_("head.description"), 0)}><meta name="twitter:description"${add_attribute("content", $_("head.description"), 0)}><!-- HEAD_svelte-sus4vx_END -->`, ""} <div id="content">${validate_component(NavBar, "NavBar").$$render($$result, {}, {}, {})} <div class="mainContainer svelte-hy9bpi"><main class="transitionContainer pixelBorder svelte-hy9bpi"><div>${slots.default ? slots.default({}) : ``}</div></main> <aside class="svelte-hy9bpi">${validate_component(ExtraData, "ExtraData").$$render($$result, {}, {}, {})}</aside></div> </div>`;
});
export {
  Layout as default
};

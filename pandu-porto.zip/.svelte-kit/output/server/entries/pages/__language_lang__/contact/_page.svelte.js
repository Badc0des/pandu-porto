import { s as subscribe } from "../../../../chunks/utils.js";
import { c as create_ssr_component, e as escape, b as add_attribute, v as validate_component } from "../../../../chunks/ssr.js";
import { $ as $locale, a as $format } from "../../../../chunks/runtime.js";
const socialLinks = {
  discord: "http://discordapp.com/users/530819150969438208",
  github: "https://github.com/JezerM",
  linkedin: "https://www.linkedin.com/in/jezer-josué-mejía-otero-111b39227/",
  email: "mailto:jezer.mejia@icloud.com"
};
const css = {
  code: ".contact.svelte-1s9wd2k a{text-decoration-line:underline;text-decoration-thickness:0.1em;color:var(--fgBlue)}",
  map: null
};
const Contact = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $locale$1, $$unsubscribe_locale;
  let $_, $$unsubscribe__;
  $$unsubscribe_locale = subscribe($locale, (value) => $locale$1 = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  console.log("	Inside contact", $locale$1);
  $$result.css.add(css);
  $$unsubscribe_locale();
  $$unsubscribe__();
  return `<div class="contact svelte-1s9wd2k"><h2>${escape($_("contact.title"))}</h2> <p><!-- HTML_TAG_START -->${$_("contact.desc_1")}<!-- HTML_TAG_END --></p> <h3 data-svelte-h="svelte-xflkm">Social links</h3> <ul data-svelte-h="svelte-oe8crm"><li><a${add_attribute("href", socialLinks.github, 0)}>GitHub</a></li> <li><a${add_attribute("href", socialLinks.linkedin, 0)}>Linkedin</a></li> <li><a${add_attribute("href", socialLinks.discord, 0)}>Discord</a></li></ul> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe__();
  return `${$$result.head += `<!-- HEAD_svelte-1k2vmum_START -->${$$result.title = `<title>${escape($_("head.contact_title"))}</title>`, ""}<!-- HEAD_svelte-1k2vmum_END -->`, ""} ${validate_component(Contact, "Contact").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};

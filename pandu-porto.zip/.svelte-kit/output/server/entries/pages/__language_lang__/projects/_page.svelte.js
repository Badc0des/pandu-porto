import { s as subscribe } from "../../../../chunks/utils.js";
import { c as create_ssr_component, e as escape, b as add_attribute, v as validate_component, d as each } from "../../../../chunks/ssr.js";
import { b as base } from "../../../../chunks/paths.js";
import { d as derived, w as writable } from "../../../../chunks/index.js";
import { $ as $locale, a as $format } from "../../../../chunks/runtime.js";
const css$2 = {
  code: ".card.svelte-1ekm4tx{display:flex;flex-direction:column;box-sizing:border-box}.cardContent.svelte-1ekm4tx{padding:1.25em}.imgContainer.svelte-1ekm4tx{aspect-ratio:16 / 10;width:100%;display:flex;justify-content:center;align-items:center}.imgContainer.svelte-1ekm4tx img{width:100%;height:auto}",
  map: null
};
const Card = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { class: className = "" } = $$props;
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  $$result.css.add(css$2);
  return `<div class="${"card " + escape(className, true) + " svelte-1ekm4tx"}"><div class="imgContainer svelte-1ekm4tx">${slots.image ? slots.image({}) : ``}</div> <div class="cardContent svelte-1ekm4tx">${slots.default ? slots.default({}) : ``}</div> </div>`;
});
const data = [
  {
    name: "Web Greeter",
    description: {
      en: "A modern, visually appealing greeter for LightDM. Fork of lightdm-webkit2-greeter.",
      es: "Un moderno y visualmente atractivo greeter para LightDM. Fork de lightdm-webkit2-greeter."
    },
    link: "https://github.com/JezerM/web-greeter",
    categories: [
      "Linux",
      "LightDM",
      "Web",
      "Python"
    ],
    color: "blue",
    image: "/thumbnails/web-greeter.avif"
  },
  {
    name: "Nody Greeter",
    description: {
      en: "LightDM greeter that allows to create wonderful themes with web technologies. Made in Node.js",
      es: "Greeter de LightDM que permite crear hermosos temas con tecnologías web. Hecho con Node.js"
    },
    link: "https://github.com/JezerM/nody-greeter",
    categories: [
      "Linux",
      "LightDM",
      "Web",
      "NodeJS"
    ],
    color: "red",
    image: "/thumbnails/nody-greeter.avif"
  },
  {
    name: "Sea Greeter",
    description: {
      en: "LightDM greeter made with WebKit2GTK. This allows to create themes with web technologies... Yeah, the same but in another language.",
      es: "Greeter de LightDM hecho con WebKit2GTK. Te permite crear temas con tecnologías web... Sí, lo mismo de antes pero en otro lenguaje."
    },
    link: "https://github.com/JezerM/sea-greeter",
    categories: [
      "Linux",
      "LightDM",
      "Web",
      "C"
    ],
    color: "orange",
    image: "/thumbnails/sea-greeter.avif"
  },
  {
    name: "Web Greeter page",
    description: {
      en: "Webpage that aims to present my three web-based greeters, as well as to contain the default and community themes.",
      es: "Página web que tiene por objetivo presentar mis 3 greeters para LightDM, así como contener los temas por defecto y de la comunidad."
    },
    link: "https://jezerm.github.io/web-greeter-page/",
    categories: [
      "Web",
      "Vue"
    ],
    color: "blue",
    image: "/thumbnails/web-greeter-page.avif"
  },
  {
    name: "Dotfiles",
    description: {
      en: "My awesome and incredible dotfiles.",
      es: "Mis increíbles, awesome!, dotfiles."
    },
    link: "https://github.com/JezerM/dotfiles",
    categories: [
      "Linux",
      "Config"
    ],
    color: "purple",
    image: "/thumbnails/dotfiles.avif"
  },
  {
    name: "HealthZone App",
    description: {
      en: "Android application to manage medical appointments.",
      es: "Aplicación de Android para gestionar citas médicas."
    },
    link: "https://github.com/JezerMejia/HealthZoneDAM",
    categories: [
      "Android",
      "Kotlin"
    ],
    color: "aqua",
    image: "/thumbnails/healthzone.avif"
  },
  {
    name: "Liberlú (Hackaton)",
    description: {
      en: "Android game for kids made in one night. I'm still surprised I was able to do this.",
      es: "Juego de Android para niños hecho en una noche. Aún me sorprende que haya sido capaz de hacer esto."
    },
    link: "https://github.com/JezerMejia/HackatonProject",
    categories: [
      "Android",
      "Kotlin"
    ],
    color: "blue",
    image: "/thumbnails/liberlu.avif"
  },
  {
    name: "Sistema de Entrada y Salida",
    description: {
      en: "A college course application to manage people Attendances in a X company.",
      es: "Una aplicación de una asignatura universitaria para manejar las Asistencias en una compañía X."
    },
    link: "https://github.com/JezerMejia/PASistemaEyS",
    categories: [
      "Linux",
      "C#"
    ],
    color: "green",
    image: "/thumbnails/sistemaeys.avif"
  },
  {
    name: "Tasky",
    description: {
      en: "Task manager that includes a Pomodoro and SOUNDS!. Made in C++ without understanding C++.",
      es: "Programa de gestión de tareas que incluye un Pomodoro y SONIDOS!. Hecho en C++ sin entender C++."
    },
    link: "https://github.com/JezerM/tasky/tree/simple",
    categories: [
      "Linux",
      "C++"
    ],
    color: "purple",
    image: "/thumbnails/tasky.avif"
  }
];
const css$1 = {
  code: "button.svelte-15qrjtg{font-size:14px;padding:0.5em 0.75em;background-color:var(--bg)}button.active.svelte-15qrjtg{background-color:var(--bgAqua)}button.svelte-15qrjtg:hover{background-color:var(--bgBlue)}:root:is(.light) button.svelte-15qrjtg:hover,:root:is(.light) button.svelte-15qrjtg:active{color:var(--bg)}",
  map: null
};
const FilterButton = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { text } = $$props;
  let { disableClick = false } = $$props;
  let { active = false } = $$props;
  if ($$props.text === void 0 && $$bindings.text && text !== void 0)
    $$bindings.text(text);
  if ($$props.disableClick === void 0 && $$bindings.disableClick && disableClick !== void 0)
    $$bindings.disableClick(disableClick);
  if ($$props.active === void 0 && $$bindings.active && active !== void 0)
    $$bindings.active(active);
  $$result.css.add(css$1);
  return `<button class="${["svelte-15qrjtg", active ? "active" : ""].join(" ").trim()}"><span>${escape(text)}</span></button> <noscript data-svelte-h="svelte-1r2cr9q"><style lang="less">@media (prefers-color-scheme: light) {
  button:hover,
  button:active {
    color: var(--bg);
  }
}</style> </noscript>`;
});
const css = {
  code: '.projectsContainer.svelte-r5e431.svelte-r5e431{display:grid;gap:1.5em;grid-template-columns:repeat(1, minmax(0, 1fr))}@media(min-width: 820px){.projectsContainer.svelte-r5e431.svelte-r5e431{grid-template-columns:repeat(2, minmax(0, 1fr))}}@media(min-width: 1280px){.projectsContainer.svelte-r5e431.svelte-r5e431{grid-template-columns:repeat(3, minmax(0, 1fr))}}@media(min-width: 1536px){.projectsContainer.svelte-r5e431.svelte-r5e431{grid-template-columns:repeat(4, minmax(0, 1fr))}}.projectsContainer.svelte-r5e431 a.svelte-r5e431{grid-column:span 1 / span 1;height:100%}.projectsContainer.svelte-r5e431 .card{background-color:var(--bg);height:100%;transition:background-color 0.25s, transform 0.5s}.projectsContainer.svelte-r5e431 .card:hover{background-color:var(--cardColor);transform:scale(1.02)}.projectsContainer.svelte-r5e431 .card>.imgContainer{background-color:var(--cardColor)}.projectsContainer.svelte-r5e431 .imgContainer>picture{display:contents;height:100%;height:-webkit-fill-available;height:fill-available;height:-moz-available}:root:is(.light) .card:hover{color:var(--bg)}.projectDescription.svelte-r5e431.svelte-r5e431{font-size:14px;margin:0}#searchContainer.svelte-r5e431.svelte-r5e431{width:100%;margin:0 0 1em;position:relative}#searchContainer.svelte-r5e431.svelte-r5e431::before{content:"";width:100%;height:100%;display:block;position:absolute;background-color:var(--fg);z-index:-1}#searchInput.svelte-r5e431.svelte-r5e431{width:-webkit-fill-available;width:fill-available;width:-moz-available;box-sizing:border-box;padding:0.75em 1em;background-color:var(--bg1);margin:0.3rem;border:none;color:var(--fg);font-family:Monocraft;font-size:14px}#searchInput.svelte-r5e431.svelte-r5e431::placeholder{color:var(--fg3)}#categoriesContainer.svelte-r5e431.svelte-r5e431{display:flex;flex-direction:row;flex-wrap:wrap;gap:0.25em;margin:0 0 1em}.card.red{--cardColor:var(--bgRed)}.card.green{--cardColor:var(--bgGreen)}.card.yellow{--cardColor:var(--bgYellow)}.card.blue{--cardColor:var(--bgBlue)}.card.purple{--cardColor:var(--bgPurple)}.card.aqua{--cardColor:var(--bgAqua)}.card.orange{--cardColor:var(--bgOrange)}',
  map: null
};
function getPngLink(link) {
  return link.replace(/\.avif/i, ".png");
}
const Projects = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $locale$1, $$unsubscribe_locale;
  let $_, $$unsubscribe__;
  let $selectedTerms, $$unsubscribe_selectedTerms;
  let $filtered, $$unsubscribe_filtered;
  $$unsubscribe_locale = subscribe($locale, (value) => $locale$1 = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  console.log("	Inside projects", $locale$1);
  const flat = data.flatMap((v) => v.categories);
  const categories = Array.from(new Set(flat));
  const selectedCategories = /* @__PURE__ */ new Set();
  const selectedTerms = writable(selectedCategories);
  $$unsubscribe_selectedTerms = subscribe(selectedTerms, (value) => $selectedTerms = value);
  let search = "";
  let term = writable("");
  const filtered = derived([term, selectedTerms, writable(data)], ([$term, $selectedTerms2, $items]) => {
    let f = $items.filter((x) => x.name.toLowerCase().includes($term.toLowerCase()));
    if ($selectedTerms2.size > 0) {
      const s = Array.from($selectedTerms2);
      f = f.filter((v) => s.every((p) => v.categories.includes(p)));
    }
    return f;
  });
  $$unsubscribe_filtered = subscribe(filtered, (value) => $filtered = value);
  function getProjectDescription(project) {
    switch ($locale$1) {
      case "en":
        return project.description.en;
      case "es":
        return project.description.es;
    }
    return "";
  }
  $$result.css.add(css);
  {
    term.set(search);
  }
  $$unsubscribe_locale();
  $$unsubscribe__();
  $$unsubscribe_selectedTerms();
  $$unsubscribe_filtered();
  return `<div id="searchContainer" class="pixelSimpleBorder svelte-r5e431"><input id="searchInput" class="pixelSimpleBorder svelte-r5e431" type="text" placeholder="Search..."${add_attribute("value", search, 0)}></div> <div id="categoriesContainer" class="svelte-r5e431">${validate_component(FilterButton, "FilterButton").$$render(
    $$result,
    {
      text: $_("projects.clear"),
      disableClick: true
    },
    {},
    {}
  )} ${each(categories, (cat) => {
    return `${validate_component(FilterButton, "FilterButton").$$render(
      $$result,
      {
        text: cat,
        active: $selectedTerms.has(cat)
      },
      {},
      {}
    )}`;
  })}</div> <div class="projectsContainer svelte-r5e431">${each($filtered, (project) => {
    return `<a${add_attribute("href", project.link, 0)} target="_blank" class="svelte-r5e431">${validate_component(Card, "Card").$$render($$result, { class: project.color }, {}, {
      image: () => {
        return `<picture slot="image"><source type="image/avif" srcset="${escape(base, true) + escape(project.image, true)}"> <img src="${escape(base, true) + escape(getPngLink(project.image), true)}" alt="" width="2880" height="1800"> </picture>`;
      },
      default: () => {
        return `<h4>${escape(project.name)}</h4> <p class="projectDescription svelte-r5e431">${escape(getProjectDescription(project))}</p> `;
      }
    })} </a>`;
  })} </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe__();
  return `${$$result.head += `<!-- HEAD_svelte-eexfvy_START -->${$$result.title = `<title>${escape($_("head.projects_title"))}</title>`, ""}<!-- HEAD_svelte-eexfvy_END -->`, ""} ${validate_component(Projects, "Projects").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};

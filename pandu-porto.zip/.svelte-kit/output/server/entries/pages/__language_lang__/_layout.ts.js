import { $ as $locale } from "../../../chunks/runtime.js";
const load = ({ params }) => {
  const { language } = params;
  switch (language) {
    case "es":
      $locale.set("es");
      break;
    case "en":
    default:
      $locale.set("en");
      break;
  }
  return { language };
};
export {
  load
};

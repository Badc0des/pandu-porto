const entries = () => {
  return [
    {
      language: "es"
    },
    {
      language: "en"
    }
  ];
};
const prerender = true;
export {
  entries,
  prerender
};

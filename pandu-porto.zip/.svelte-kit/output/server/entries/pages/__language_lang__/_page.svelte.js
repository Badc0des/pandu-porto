import { s as subscribe } from "../../../chunks/utils.js";
import { c as create_ssr_component, d as each, e as escape, b as add_attribute, a as add_styles, v as validate_component } from "../../../chunks/ssr.js";
import { b as base } from "../../../chunks/paths.js";
import { $ as $locale, a as $format } from "../../../chunks/runtime.js";
const css$1 = {
  code: ".iconsContainer.svelte-ka8ynk.svelte-ka8ynk{display:flex;flex-direction:row;gap:0.75em;flex-wrap:wrap}.iconsContainer.svelte-ka8ynk>img.svelte-ka8ynk{width:2em;height:2em;image-rendering:pixelated}",
  map: null
};
const LanguageIcons = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const imageNames = [
    "C",
    "Rust",
    "TypeScript",
    "NodeJS",
    "Svelte",
    "Vue",
    "MySQL",
    "Html",
    "Swift",
    "CSharp",
    "Kotlin",
    "Java"
  ];
  $$result.css.add(css$1);
  return `<div class="iconsContainer svelte-ka8ynk">${each(imageNames, (name) => {
    return `<img src="${escape(base, true) + "/icons/" + escape(name, true) + ".png"}"${add_attribute("alt", name, 0)}${add_attribute("title", name, 0)} class="svelte-ka8ynk">`;
  })} </div>`;
});
const css = {
  code: ".infoContainer.svelte-595tsg.svelte-595tsg{display:flex;flex-direction:column;justify-content:start;align-items:center;gap:1.5em;margin-bottom:1.5em}@media(min-width: 820px){.infoContainer.svelte-595tsg.svelte-595tsg{flex-direction:row}}.picture.svelte-595tsg.svelte-595tsg{display:block;width:11.25em;height:11.25em;mask-size:100%;-webkit-mask-size:100%}.picture.svelte-595tsg>img.svelte-595tsg{width:100%;height:100%}.pictureContainer.svelte-595tsg.svelte-595tsg{background-color:var(--fgPurple);padding:0.4em;mask-size:100%;mask-repeat:no-repeat;-webkit-mask-size:100%;-webkit-mask-repeat:no-repeat}",
  map: null
};
const Pages = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $locale$1, $$unsubscribe_locale;
  let $_, $$unsubscribe__;
  $$unsubscribe_locale = subscribe($locale, (value) => $locale$1 = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const CircleUrl = `${base}/Circle.png`;
  console.log("	Inside Home", $locale$1);
  $$result.css.add(css);
  $$unsubscribe_locale();
  $$unsubscribe__();
  return `<div><div class="infoContainer svelte-595tsg"><div class="pictureContainer svelte-595tsg"${add_styles({
    "mask-image": `url('${CircleUrl}')`,
    "-webkit-mask-image": `url('${CircleUrl}')`
  })}><picture class="picture svelte-595tsg"${add_styles({
    "mask-image": `url('${CircleUrl}')`,
    "-webkit-mask-image": `url('${CircleUrl}')`
  })} data-svelte-h="svelte-euhtys"><source type="image/avif" srcset="${escape(base, true) + "/JezerPicture.avif"}"> <img src="${escape(base, true) + "/JezerPicture.png"}" alt="JezerM anime" class="svelte-595tsg"></picture></div> <div id="infoSubContainer"><h2 data-svelte-h="svelte-1qeqddm">Jezer Mejía</h2> <p>${escape($_("home.info_1"))}<br> ${escape($_("home.info_2"))}<br> ${escape($_("home.info_3"))}</p> ${validate_component(LanguageIcons, "LanguageIcons").$$render($$result, {}, {}, {})}</div></div> <div id="aboutMeContainer"><h2>${escape($_("home.about_title"))}</h2> <p>${escape($_("home.about_1"))}</p> <p>${escape($_("home.about_2"))}</p> <p>${escape($_("home.about_3"))}</p></div> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe__();
  return `${$$result.head += `<!-- HEAD_svelte-1r2dx4h_START -->${$$result.title = `<title>${escape($_("head.home_title"))}</title>`, ""}<!-- HEAD_svelte-1r2dx4h_END -->`, ""} ${validate_component(Pages, "Home").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};

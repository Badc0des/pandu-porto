import * as fs from "fs";
const entries = () => {
  const dir = fs.readdirSync("src/posts/", { withFileTypes: true, recursive: false });
  const posts = dir.reduce((filtered, value) => {
    if (value.isFile() && value.name.endsWith(".md")) {
      filtered.push({ post: value.name.replace(/(.*)(\.md)/, "$1") });
    }
    return filtered;
  }, []);
  return posts;
};
const prerender = true;
export {
  entries,
  prerender
};

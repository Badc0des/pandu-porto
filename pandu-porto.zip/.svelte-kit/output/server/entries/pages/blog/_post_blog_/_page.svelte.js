import { c as create_ssr_component, e as escape, v as validate_component, m as missing_component } from "../../../../chunks/ssr.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  return `${$$result.head += `<!-- HEAD_svelte-1iyajdg_START -->${$$result.title = `<title>Blog - ${escape(data.title)}</title>`, ""}<!-- HEAD_svelte-1iyajdg_END -->`, ""} <article><h1>${escape(data.title)}</h1> <p>Published: ${escape(data.date)}</p> ${validate_component(data.content || missing_component, "svelte:component").$$render($$result, {}, {}, {})}</article>`;
});
export {
  Page as default
};

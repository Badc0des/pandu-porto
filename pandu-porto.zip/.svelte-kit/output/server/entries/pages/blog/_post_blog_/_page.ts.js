const __variableDynamicImportRuntimeHelper = (glob, path) => {
  const v = glob[path];
  if (v) {
    return typeof v === "function" ? v() : Promise.resolve(v);
  }
  return new Promise((_, reject) => {
    (typeof queueMicrotask === "function" ? queueMicrotask : setTimeout)(reject.bind(null, new Error("Unknown variable dynamic import: " + path)));
  });
};
const load = async ({ params }) => {
  const post = await __variableDynamicImportRuntimeHelper(/* @__PURE__ */ Object.assign({ "../../../posts/2023-06-29.md": () => import("../../../../chunks/2023-06-29.js"), "../../../posts/2023-06-30.md": () => import("../../../../chunks/2023-06-30.js") }), `../../../posts/${params.post}.md`);
  const { title, date, image } = post.metadata;
  const content = post.default;
  return {
    content,
    title,
    date,
    image
  };
};
export {
  load
};

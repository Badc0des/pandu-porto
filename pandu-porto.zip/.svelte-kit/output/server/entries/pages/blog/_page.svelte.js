import { c as create_ssr_component, d as each, b as add_attribute, e as escape } from "../../../chunks/ssr.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  return `${$$result.head += `<!-- HEAD_svelte-10h7psl_START -->${$$result.title = `<title>Blog</title>`, ""}<!-- HEAD_svelte-10h7psl_END -->`, ""} <ul>${each(data.posts, (post) => {
    return `<li><a${add_attribute("href", post.path, 0)}>${escape(post.meta.title)} - ${escape(post.meta.date)}</a> </li>`;
  })}</ul>`;
});
export {
  Page as default
};

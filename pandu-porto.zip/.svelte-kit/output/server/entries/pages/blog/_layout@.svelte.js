import { s as subscribe } from "../../../chunks/utils.js";
import { c as create_ssr_component, e as escape } from "../../../chunks/ssr.js";
import { b as base } from "../../../chunks/paths.js";
import { $ as $locale } from "../../../chunks/runtime.js";
const css = {
  code: "main.svelte-mtng3w{padding:2em}",
  map: null
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $locale$1, $$unsubscribe_locale;
  $$unsubscribe_locale = subscribe($locale, (value) => $locale$1 = value);
  let baseLocale = $locale$1 == "en" ? "" : $locale;
  $$result.css.add(css);
  $$unsubscribe_locale();
  return `<div id="content"><a href="${escape(base, true) + "/" + escape(baseLocale, true)}">Portfolio</a> <a href="${escape(base, true) + "/blog"}" data-svelte-h="svelte-1xxinhy">Blog</a> <main class="svelte-mtng3w">${slots.default ? slots.default({}) : ``}</main> </div>`;
});
export {
  Layout as default
};

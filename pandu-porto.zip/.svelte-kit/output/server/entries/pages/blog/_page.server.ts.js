import { b as base } from "../../../chunks/paths.js";
const fetchMarkdownPosts = async () => {
  const allPostFiles = /* @__PURE__ */ Object.assign({ "/src/posts/2023-06-29.md": () => import("../../../chunks/2023-06-29.js"), "/src/posts/2023-06-30.md": () => import("../../../chunks/2023-06-30.js") });
  const iterablePostFiles = Object.entries(allPostFiles);
  const allPosts = await Promise.all(
    iterablePostFiles.map(async ([path, resolver]) => {
      const { metadata } = await resolver();
      const postName = path.replace(/\/src\/posts\/(.*)\.md/, "$1");
      const postPath = `${base}/blog/${postName}`;
      return {
        meta: metadata,
        path: postPath
      };
    })
  );
  return allPosts;
};
const load = async () => {
  const posts = await fetchMarkdownPosts();
  return {
    posts
  };
};
export {
  load
};

const match = (param) => {
  return /^(es|en)$/.test(param);
};
export {
  match
};

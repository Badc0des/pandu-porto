export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "portfolio/_app",
	assets: new Set(["apple-touch-icon-144x144.png","apple-touch-icon-152x152.png","apple-touch-icon-180x180.png","apple-touch-icon-194x194.png","apple-touch-icon-550x550.png","apple-touch-icon-60x60.png","apple-touch-icon-precomposed.png","apple-touch-icon.png","Circle.png","cv/english.pdf","cv/spanish.pdf","favicon.ico","favicon.png","icons/C.png","icons/CaretDown.png","icons/Contact.png","icons/CSharp.png","icons/Discord.png","icons/Folder.png","icons/GitHub.png","icons/Home.png","icons/Html.png","icons/Java.png","icons/Kotlin.png","icons/LinkedIn.png","icons/Moon.png","icons/MySQL.png","icons/NodeJS.png","icons/Python.png","icons/Rust.png","icons/Sun.png","icons/Svelte.png","icons/Swift.png","icons/TypeScript.png","icons/Vue.png","JezerPicture.avif","JezerPicture.png","Monocraft.otf","queries.css","thumbnails/dotfiles.avif","thumbnails/dotfiles.png","thumbnails/healthzone.avif","thumbnails/healthzone.png","thumbnails/liberlu.avif","thumbnails/liberlu.png","thumbnails/nody-greeter.avif","thumbnails/nody-greeter.png","thumbnails/sea-greeter.avif","thumbnails/sea-greeter.png","thumbnails/sistemaeys.avif","thumbnails/sistemaeys.png","thumbnails/tasky.avif","thumbnails/tasky.png","thumbnails/web-greeter-page.avif","thumbnails/web-greeter-page.png","thumbnails/web-greeter.avif","thumbnails/web-greeter.png","web-card-1200x628.png","web-card.png","web-thumbnail.png"]),
	mimeTypes: {".png":"image/png",".pdf":"application/pdf",".avif":"image/avif",".otf":"font/otf",".css":"text/css"},
	_: {
		client: {"start":"_app/immutable/entry/start.xLh09c-a.js","app":"_app/immutable/entry/app.MZH65SA_.js","imports":["_app/immutable/entry/start.xLh09c-a.js","_app/immutable/chunks/entry.6OwFKuot.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/index.rK6CHotB.js","_app/immutable/chunks/paths.wPZ2Tgq1.js","_app/immutable/entry/app.MZH65SA_.js","_app/immutable/chunks/preload-helper.0HuHagjb.js","_app/immutable/chunks/scheduler.ijX8_RjN.js","_app/immutable/chunks/index.--F_gRC0.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js'))
		],
		routes: [
			{
				id: "/blog",
				pattern: /^\/blog\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/blog/[post=blog]",
				pattern: /^\/blog\/([^/]+?)\/?$/,
				params: [{"name":"post","matcher":"blog","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/[[language=lang]]/contact",
				pattern: /^(?:\/([^/]+))?\/contact\/?$/,
				params: [{"name":"language","matcher":"lang","optional":true,"rest":false,"chained":true}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/[[language=lang]]/projects",
				pattern: /^(?:\/([^/]+))?\/projects\/?$/,
				params: [{"name":"language","matcher":"lang","optional":true,"rest":false,"chained":true}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/[[language=lang]]",
				pattern: /^(?:\/([^/]+))?\/?$/,
				params: [{"name":"language","matcher":"lang","optional":true,"rest":false,"chained":true}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 6 },
				endpoint: null
			}
		],
		matchers: async () => {
			const { match: blog } = await import ('./entries/matchers/blog.js')
			const { match: lang } = await import ('./entries/matchers/lang.js')
			return { blog, lang };
		}
	}
}
})();

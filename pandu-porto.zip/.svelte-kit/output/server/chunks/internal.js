import { c as create_ssr_component, s as setContext, v as validate_component, m as missing_component } from "./ssr.js";
import "./paths.js";
let public_env = {};
let safe_public_env = {};
function set_private_env(environment) {
}
function set_public_env(environment) {
  public_env = environment;
}
function set_safe_public_env(environment) {
  safe_public_env = environment;
}
function afterUpdate() {
}
let prerendering = false;
function set_building() {
}
function set_prerendering() {
  prerendering = true;
}
const Root = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { stores } = $$props;
  let { page } = $$props;
  let { constructors } = $$props;
  let { components = [] } = $$props;
  let { form } = $$props;
  let { data_0 = null } = $$props;
  let { data_1 = null } = $$props;
  let { data_2 = null } = $$props;
  {
    setContext("__svelte__", stores);
  }
  afterUpdate(stores.page.notify);
  if ($$props.stores === void 0 && $$bindings.stores && stores !== void 0)
    $$bindings.stores(stores);
  if ($$props.page === void 0 && $$bindings.page && page !== void 0)
    $$bindings.page(page);
  if ($$props.constructors === void 0 && $$bindings.constructors && constructors !== void 0)
    $$bindings.constructors(constructors);
  if ($$props.components === void 0 && $$bindings.components && components !== void 0)
    $$bindings.components(components);
  if ($$props.form === void 0 && $$bindings.form && form !== void 0)
    $$bindings.form(form);
  if ($$props.data_0 === void 0 && $$bindings.data_0 && data_0 !== void 0)
    $$bindings.data_0(data_0);
  if ($$props.data_1 === void 0 && $$bindings.data_1 && data_1 !== void 0)
    $$bindings.data_1(data_1);
  if ($$props.data_2 === void 0 && $$bindings.data_2 && data_2 !== void 0)
    $$bindings.data_2(data_2);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      stores.page.set(page);
    }
    $$rendered = `  ${constructors[1] ? `${validate_component(constructors[0] || missing_component, "svelte:component").$$render(
      $$result,
      { data: data_0, this: components[0] },
      {
        this: ($$value) => {
          components[0] = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${constructors[2] ? `${validate_component(constructors[1] || missing_component, "svelte:component").$$render(
            $$result,
            { data: data_1, this: components[1] },
            {
              this: ($$value) => {
                components[1] = $$value;
                $$settled = false;
              }
            },
            {
              default: () => {
                return `${validate_component(constructors[2] || missing_component, "svelte:component").$$render(
                  $$result,
                  { data: data_2, form, this: components[2] },
                  {
                    this: ($$value) => {
                      components[2] = $$value;
                      $$settled = false;
                    }
                  },
                  {}
                )}`;
              }
            }
          )}` : `${validate_component(constructors[1] || missing_component, "svelte:component").$$render(
            $$result,
            { data: data_1, form, this: components[1] },
            {
              this: ($$value) => {
                components[1] = $$value;
                $$settled = false;
              }
            },
            {}
          )}`}`;
        }
      }
    )}` : `${validate_component(constructors[0] || missing_component, "svelte:component").$$render(
      $$result,
      { data: data_0, form, this: components[0] },
      {
        this: ($$value) => {
          components[0] = $$value;
          $$settled = false;
        }
      },
      {}
    )}`} ${``}`;
  } while (!$$settled);
  return $$rendered;
});
const options = {
  app_dir: "_app",
  app_template_contains_nonce: false,
  csp: { "mode": "auto", "directives": { "upgrade-insecure-requests": false, "block-all-mixed-content": false }, "reportOnly": { "upgrade-insecure-requests": false, "block-all-mixed-content": false } },
  csrf_check_origin: true,
  embedded: false,
  env_public_prefix: "PUBLIC_",
  env_private_prefix: "",
  hooks: null,
  // added lazily, via `get_hooks`
  preload_strategy: "modulepreload",
  root: Root,
  service_worker: false,
  templates: {
    app: ({ head, body, assets, nonce, env }) => '<!DOCTYPE html>\r\n<html lang="%lang%">\r\n  <head>\r\n    <meta charset="utf-8" />\r\n    <link rel="shortcut icon" type="image/x-icon" href="' + assets + '/favicon.ico?v=3" />\r\n    <link rel="icon" type="image/png" href="' + assets + '/favicon.png?v=2" />\r\n    <link\r\n      rel="apple-touch-icon"\r\n      type="image/png"\r\n      sizes="60x60"\r\n      href="' + assets + '/apple-touch-icon-60x60.png?v=2"\r\n    />\r\n    <link\r\n      rel="apple-touch-icon"\r\n      type="image/png"\r\n      href="' + assets + '/apple-touch-icon.png?v=2"\r\n    />\r\n    <link\r\n      rel="apple-touch-icon"\r\n      type="image/png"\r\n      sizes="144x144"\r\n      href="' + assets + '/apple-touch-icon-144x144.png?v=2"\r\n    />\r\n    <link\r\n      rel="apple-touch-icon"\r\n      type="image/png"\r\n      sizes="152x152"\r\n      href="' + assets + '/apple-touch-icon-152x152.png?v=2"\r\n    />\r\n    <link\r\n      rel="apple-touch-icon"\r\n      type="image/png"\r\n      sizes="180x180"\r\n      href="' + assets + '/apple-touch-icon-180x180.png?v=2"\r\n    />\r\n    <link\r\n      rel="apple-touch-icon"\r\n      type="image/png"\r\n      sizes="194x194"\r\n      href="' + assets + '/apple-touch-icon-194x194.png?v=2"\r\n    />\r\n    <link\r\n      rel="apple-touch-icon"\r\n      type="image/png"\r\n      sizes="550x550"\r\n      href="' + assets + `/apple-touch-icon-550x550.png?v=2"\r
    />\r
    <meta name="viewport" content="width=device-width" />\r
    <meta name="color-scheme" content="dark light" />\r
\r
    <meta property="og:type" content="website" />\r
    <meta property="og:title" content="JezerM's portfolio" />\r
    <meta property="og:image" content="https://portfolio-jezerm.vercel.app/web-card.png" />\r
    <meta property="og:image:width" content="1800" />\r
    <meta property="og:image:height" content="942" />\r
    <meta property="og:image" content="https://portfolio-jezerm.vercel.app/web-card-1200x628.png" />\r
    <meta property="og:image:width" content="1200" />\r
    <meta property="og:image:height" content="628" />\r
\r
    <meta name="twitter:title" content="JezerM's portfolio" />\r
    <meta property="twitter:card" content="summary_large_image" />\r
    <meta property="twitter:image" content="https://portfolio-jezerm.vercel.app/web-card.png" />\r
\r
    ` + head + '\r\n    <script>\r\n      localStorage.theme === "dark" ||\r\n      (!("theme" in localStorage) && window.matchMedia("(prefers-color-scheme: dark)").matches)\r\n        ? document.documentElement.classList.remove("light")\r\n        : document.documentElement.classList.add("light");\r\n    <\/script>\r\n    <noscript>\r\n      <link rel="stylesheet" href="' + assets + '/queries.css" />\r\n    </noscript>\r\n  </head>\r\n  <body>\r\n    <div>' + body + "</div>\r\n  </body>\r\n</html>\r\n",
    error: ({ status, message }) => '<!doctype html>\n<html lang="en">\n	<head>\n		<meta charset="utf-8" />\n		<title>' + message + `</title>

		<style>
			body {
				--bg: white;
				--fg: #222;
				--divider: #ccc;
				background: var(--bg);
				color: var(--fg);
				font-family:
					system-ui,
					-apple-system,
					BlinkMacSystemFont,
					'Segoe UI',
					Roboto,
					Oxygen,
					Ubuntu,
					Cantarell,
					'Open Sans',
					'Helvetica Neue',
					sans-serif;
				display: flex;
				align-items: center;
				justify-content: center;
				height: 100vh;
				margin: 0;
			}

			.error {
				display: flex;
				align-items: center;
				max-width: 32rem;
				margin: 0 1rem;
			}

			.status {
				font-weight: 200;
				font-size: 3rem;
				line-height: 1;
				position: relative;
				top: -0.05rem;
			}

			.message {
				border-left: 1px solid var(--divider);
				padding: 0 0 0 1rem;
				margin: 0 0 0 1rem;
				min-height: 2.5rem;
				display: flex;
				align-items: center;
			}

			.message h1 {
				font-weight: 400;
				font-size: 1em;
				margin: 0;
			}

			@media (prefers-color-scheme: dark) {
				body {
					--bg: #222;
					--fg: #ddd;
					--divider: #666;
				}
			}
		</style>
	</head>
	<body>
		<div class="error">
			<span class="status">` + status + '</span>\n			<div class="message">\n				<h1>' + message + "</h1>\n			</div>\n		</div>\n	</body>\n</html>\n"
  },
  version_hash: "x871vi"
};
async function get_hooks() {
  return {
    ...await import("./hooks.server.js")
  };
}
export {
  set_private_env as a,
  prerendering as b,
  set_public_env as c,
  set_safe_public_env as d,
  set_building as e,
  set_prerendering as f,
  get_hooks as g,
  options as o,
  public_env as p,
  safe_public_env as s
};

import { $ as $locale } from "./runtime.js";
import { g as get_store_value } from "./utils.js";
const handle = ({ event, resolve }) => {
  return resolve(event, {
    transformPageChunk: ({ html }) => html.replace("%lang%", get_store_value($locale))
  });
};
export {
  handle
};

import { c as create_ssr_component } from "./ssr.js";
const metadata = {
  "title": "Primer post",
  "date": "2023-06-29T00:00:00.000Z",
  "image": ""
};
const _2023_06_29 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return ``;
});
export {
  _2023_06_29 as default,
  metadata
};

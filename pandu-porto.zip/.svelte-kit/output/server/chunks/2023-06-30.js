import { c as create_ssr_component } from "./ssr.js";
const metadata = {
  "title": "Segundo post",
  "date": "2023-06-30T00:00:00.000Z",
  "image": ""
};
const _2023_06_30 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<h2 data-svelte-h="svelte-16aj5bg">Mi blog</h2> <p data-svelte-h="svelte-149goed">Sí, un blog. Qué original.</p>`;
});
export {
  _2023_06_30 as default,
  metadata
};

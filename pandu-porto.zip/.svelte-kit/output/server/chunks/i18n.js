import { c as addMessages, i as init, $ as $locale } from "./runtime.js";
import { d as derived } from "./index.js";
import { b as base } from "./paths.js";
const navigation$1 = {
  home: "Home",
  projects: "My projects",
  contact: "Contact me",
  blog: "Blog",
  toggle_dark_mode: "Toggle dark mode",
  discord_user: "Discord user",
  github_profile: "GitHub profile",
  linkedin_profile: "LinkedIn profile"
};
const head$1 = {
  description: "My portfolio. It includes my information, the projects I have made and my contact info.",
  home_title: "JezerM's portfolio",
  projects_title: "Portfolio - Projects",
  contact_title: "Portfolio - Contact"
};
const extra_data$1 = {
  title: "Extra data",
  age: "Age",
  birthday: "Birthday",
  birthday_value: "Nov, 5th",
  country: "Country",
  gender: "Gender",
  gender_value: "Male",
  cv_open: "Open",
  language: "Language"
};
const home$1 = {
  info_1: "I love Linux, coffee, Physics and Open Source.",
  info_2: "Low level programming enthusiast.",
  info_3: "UCA Nicaragua student. #SomosUCA",
  about_title: "About me",
  about_1: "I'm Jezer Josué Mejía Otero and I'm a developer just for fun. I love to create things that everyone could benefit of, investing my time in open source development, from which we can find some Linux applications, web pages, terminal based programs and so much more.",
  about_2: "My true passion is Physics, but that will have to wait until I move to a country that offer this career~",
  about_3: "As stated above, I love Linux! Hence, I also love the terminal. I've always liked TypeScript and C, but Rust has recently taken a part in my heart."
};
const projects$1 = {
  clear: "Clear"
};
const contact$1 = {
  title: "Contact me",
  desc_1: 'If you want to hire me, ask me about my projects or anything else, you can contact me through <a href="mailto:jezer.mejia@icloud.com">Email</a> or Discord.'
};
const en = {
  navigation: navigation$1,
  head: head$1,
  extra_data: extra_data$1,
  home: home$1,
  projects: projects$1,
  contact: contact$1
};
const navigation = {
  home: "Inicio",
  projects: "Mis proyectos",
  contact: "Contáctame",
  blog: "Blog",
  toggle_dark_mode: "Alternar modo oscuro",
  discord_user: "Usuario de Discord",
  github_profile: "Perfil de GitHub",
  linkedin_profile: "Perfil de LinkedIn"
};
const head = {
  description: "Mi portfolio. Incluye mi información, los proyectos que he realizado y mi información de contacto.",
  home_title: "JezerM's portfolio",
  projects_title: "Portfolio - Proyectos",
  contact_title: "Portfolio - Contacto"
};
const extra_data = {
  title: "Datos extras",
  age: "Edad",
  birthday: "Cumpleaños",
  birthday_value: "5 de Nov",
  country: "País",
  gender: "Género",
  gender_value: "Masculino",
  cv_open: "Abrir",
  language: "Idioma"
};
const home = {
  info_1: "Me encanta Linux, el café, la Física y el Open Source.",
  info_2: "Entusiasta de la programación de bajo nivel.",
  info_3: "Estudiante de la UCA Nicaragua. #SomosUCA",
  about_title: "Sobre mí",
  about_1: "Soy Jezer Josué Mejía Otero, un desarrollador sólo por diversión. Me encanta crear cosas de las que cualquiera pueda beneficiarse, invirtiendo mi tiempo en el desarrollo open source de lo cual podemos encontrar algunas aplicaciones de Linux, páginas webs, programas de terminal y mucho más.",
  about_2: "Mi verdadera pasión es la Física, pero eso tendrá que esperar hasta que me mueva a un país que ofrezca esta carrera~",
  about_3: "Como se mencionó antes, ¡Me encanta Linux! Por ende, también me encantan las terminales. Siempre me ha gustado TypeScript y C, pero Rust recientemente se ha ganado un lugar en mi corazón."
};
const projects = {
  clear: "Limpiar"
};
const contact = {
  title: "Contáctame",
  desc_1: 'Si quieres contratarme, preguntarme sobre mis proyectos o cualquier otra cosa, puedes contactarme por <a href="mailto:jezer.mejia@icloud.com">Email</a> o Discord.'
};
const es = {
  navigation,
  head,
  extra_data,
  home,
  projects,
  contact
};
addMessages("en", en);
addMessages("es", es);
const defaultLocale = "en";
init({
  fallbackLocale: defaultLocale,
  initialLocale: defaultLocale
});
const baseLocale = derived($locale, ($locale2) => {
  let endRoute = `${base}/${$locale2}`;
  if ($locale2 == "en")
    endRoute = `${base}`;
  return endRoute.replace(/([^:]\/)\/+/g, "$1");
});
export {
  baseLocale as b
};

import { match as blog } from "../../../src/params/blog.ts";
import { match as lang } from "../../../src/params/lang.ts";

export const matchers = { blog, lang };
import * as universal from "../../../../src/routes/blog/[post=blog]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/blog/[post=blog]/+page.svelte";
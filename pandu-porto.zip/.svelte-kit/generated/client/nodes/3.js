import * as universal from "../../../../src/routes/[[language=lang]]/+layout.ts";
export { universal };
export { default as component } from "../../../../src/routes/[[language=lang]]/+layout.svelte";
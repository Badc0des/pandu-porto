export const socialLinks = {
  discord: "http://discordapp.com/users/530819150969438208",
  github: "https://github.com/Badc0des",
  linkedin: "https://www.linkedin.com/in/pandu-satria-517b8823a/",
  email: "mailto:pandudotid1337@gmail.com"
} as const;
